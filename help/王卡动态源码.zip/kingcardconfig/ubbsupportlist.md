ubb支持列表

取用户ip [getuserip] [getip]

取用户ua [getua]

取host [gethost]

取时间 [gettime]

取版本 [getversion]

更多ubb持续添加更新中。。。
