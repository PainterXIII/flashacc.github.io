网站列表

http://cs.kingcardconfig.ml/k/get_config.php
http://cs.xxzml.cn/k/get_config.php

使用CDN的网站列表

http://cs.kingcardconfigcdn.ml/k/get_config.php
http://xxzml.cn/k/get_config.php

更多网站持续添加更新中。。。
