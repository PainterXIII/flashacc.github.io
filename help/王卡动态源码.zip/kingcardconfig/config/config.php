<?php
/*
第一修改者为作者
修改者:lbr-dev,预留
修改者GITHUB:lbr-dev(https://github.com/lbr-dev/),预留
修改者QQ:lbr-dev(3170482764),预留
本项目开源地址:https://github.com/kingcardconfig/kingcardconfig/
*/
$versionnumber='100220200120162500';
$version='1.002-20200120162500';
/*
以下为可修改项。
*/
$configcheckguidandtokenurl='http://cs.xxzml.cn/kingcardconfigtools/checkguidandtoken/';
$configcheckguidandtokenproxyip='157.255.173.182';
$configcheckguidandtokenproxyport='8090';
$configcheckguidandtokenua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configcheckguidandtokenhtml='Proxy Server Accessing checkguidandtoken Web Page Successfully ！';
$configwkdtconfig1url='http://cs.kingcardconfig.ml/k/get_config.php';
$configwkdtconfig1ua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configcronsuccessmessage='cron successfully !';
$configcronlogfilename='cronlog';
$configwkdtconfigfilename='wkdtconfig';
$configtimeout='3';
$configisgziphtmlfilename='isgziphtml';
$configcronlogonoroff='off';
$configwkdtconfig2url='http://cs.kingcardconfigcdn.ml/k/get_config.php';
$configwkdtconfig2ua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configwkdtconfig3url='http://cs.xxzml.cn/k/get_config.php';
$configwkdtconfig3ua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configwkdtconfig4url='http://xxzml.cn/k/get_config.php';
$configwkdtconfig4ua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configwkdtconfig5url='http://helper.vtop.design/KingCardServices/get_config.php';
$configwkdtconfig5ua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configkingcardconfigcheckupdateurl='http://cs.kingcardconfig.ml/666666/u/k/checkupdate';
$configkingcardconfigcheckupdateua='Mozilla/5.0 Linux; U; Android 7.0; zh-cn; BND-AL00 Build/HONORBND-AL00 AppleWebKit/537.36 KHTML, like Gecko Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.3 Mobile Safari/537.36';
$configkingcardconfigindexubborhtml='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Expires" content="0" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Cache-control" content="no-cache" />
<meta http-equiv="Cache" content="no-cache" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
<title>kingcardconfig 首页</title>
<link href="css/index.css" rel="stylesheet" type="text/css" />
</head>
<body id="index">
<h2>kingcardconfig 首页</h2>
<p>本站是 kingcardconfig 首页</p>
<p>XMPP:lbr@404.city</p>
<p>XMPP群:qqllqmlgroups@chat.404.city</p>
<p>联系邮箱: <a href = "mailto:lbr-dev@yandex.com">lbr-dev@yandex.com</a></p>
<p>本项目github开源地址: <a href = "https://github.com/kingcardconfig/kingcardconfig/">https://github.com/kingcardconfig/kingcardconfig/</a></p>
<p>官方网站: <a href = "http://kingcardconfig.ml/">http://kingcardconfig.ml</a></p>
<p><a href = "submitguidandtoken.php">提交配置</a></p>
<p>kingcardconfig版本:[getversion]</p>
<p>您的ip是:[getuserip]</p>
<!-- <a href = "?">?</body>a>  //-->
</body>
</html>';
$configkingcardconfigsubmitguidandtokenubborhtml='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Expires" content="0" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Cache-control" content="no-cache" />
<meta http-equiv="Cache" content="no-cache" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
<title>kingcardconfig 手动提交GUID和TOKEN配置页</title>
<link href="css/submitguidandtoken.css" rel="stylesheet" type="text/css" />
</head>
<body id="index">
<p>kingcardconfig 手动提交GUID和TOKEN配置页</p>
<form action="submitguidandtoken.php" name="form" id="form">
<p><input name="submit" type="hidden" id="submit" value="yes" /></p>
<p><label for="guid">GUID:</label><input type="text" name="guid" id="guid" /></p>
<p><label for="token">TOKEN:</label><input type="text" name="token" id="token" /></p>
<p><input type="submit" name="submit2" id="submit2" value="提交" /> <input type="reset" name="submit3" id="submit3" value="重置" /></p>
</form>
<p>您的ip是:[getuserip]</p>
</body>
</html>';
$configkccedkey='kccedkey';

?>